// Lightweight JSON-file "database".
// Good for small/medium teams (20-200). Swap for Postgres/MySQL later
// by re-implementing this same module interface if you outgrow it.

const fs = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "data");
const EMPLOYEES_FILE = path.join(DATA_DIR, "employees.json");
const ATTENDANCE_FILE = path.join(DATA_DIR, "attendance.json");
const SCREENSHOTS_FILE = path.join(DATA_DIR, "screenshots.json");
const ACTIVITY_FILE = path.join(DATA_DIR, "activity.json");
const BROWSING_FILE = path.join(DATA_DIR, "browsing.json");
const CATEGORIES_FILE = path.join(DATA_DIR, "categories.json");
const SCREENSHOTS_DIR = path.join(DATA_DIR, "screenshot-images");

function ensureFile(file, defaultValue) {
  if (!fs.existsSync(file)) {
    fs.writeFileSync(file, JSON.stringify(defaultValue, null, 2));
  }
}

const DEFAULT_CATEGORIES = [
  { id: "default-1", type: "app", name: "code", label: "productive" },
  { id: "default-2", type: "app", name: "vscode", label: "productive" },
  { id: "default-3", type: "app", name: "excel", label: "productive" },
  { id: "default-4", type: "app", name: "word", label: "productive" },
  { id: "default-5", type: "app", name: "slack", label: "neutral" },
  { id: "default-6", type: "app", name: "outlook", label: "productive" },
  { id: "default-7", type: "domain", name: "youtube.com", label: "unproductive" },
  { id: "default-8", type: "domain", name: "facebook.com", label: "unproductive" },
  { id: "default-9", type: "domain", name: "instagram.com", label: "unproductive" },
  { id: "default-10", type: "domain", name: "github.com", label: "productive" },
  { id: "default-11", type: "domain", name: "stackoverflow.com", label: "productive" },
];

function init() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(SCREENSHOTS_DIR)) fs.mkdirSync(SCREENSHOTS_DIR, { recursive: true });
  ensureFile(EMPLOYEES_FILE, []);
  ensureFile(ATTENDANCE_FILE, []);
  ensureFile(SCREENSHOTS_FILE, []);
  ensureFile(ACTIVITY_FILE, []);
  ensureFile(BROWSING_FILE, []);
  ensureFile(CATEGORIES_FILE, DEFAULT_CATEGORIES);
}

function readJSON(file) {
  return JSON.parse(fs.readFileSync(file, "utf-8"));
}

function writeJSON(file, data) {
  const tmp = file + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, file);
}

// ---------- Employees ----------
function getEmployees() {
  return readJSON(EMPLOYEES_FILE);
}

function getEmployeeByEmail(email) {
  return getEmployees().find((e) => e.email.toLowerCase() === email.toLowerCase());
}

function getEmployeeById(id) {
  return getEmployees().find((e) => e.id === id);
}

function getEmployeeByAgentToken(agentToken) {
  return getEmployees().find((e) => e.agentToken === agentToken);
}

function setAgentToken(employeeId, agentToken) {
  const employees = getEmployees();
  const idx = employees.findIndex((e) => e.id === employeeId);
  if (idx === -1) return null;
  employees[idx].agentToken = agentToken;
  saveEmployees(employees);
  return employees[idx];
}

function revokeAgentToken(employeeId) {
  return setAgentToken(employeeId, null);
}

function saveEmployees(employees) {
  writeJSON(EMPLOYEES_FILE, employees);
}

function addEmployee(employee) {
  const employees = getEmployees();
  employees.push(employee);
  saveEmployees(employees);
  return employee;
}

// ---------- Attendance ----------
function getAttendance() {
  return readJSON(ATTENDANCE_FILE);
}

function saveAttendance(records) {
  writeJSON(ATTENDANCE_FILE, records);
}

function getOpenSessionForEmployee(employeeId) {
  const records = getAttendance();
  return records.find((r) => r.employeeId === employeeId && r.checkOut === null);
}

function addAttendanceRecord(record) {
  const records = getAttendance();
  records.push(record);
  saveAttendance(records);
  return record;
}

function updateAttendanceRecord(id, updates) {
  const records = getAttendance();
  const idx = records.findIndex((r) => r.id === id);
  if (idx === -1) return null;
  records[idx] = { ...records[idx], ...updates };
  saveAttendance(records);
  return records[idx];
}

function getAttendanceForEmployee(employeeId) {
  return getAttendance()
    .filter((r) => r.employeeId === employeeId)
    .sort((a, b) => new Date(b.checkIn) - new Date(a.checkIn));
}

// ---------- Screenshots ----------
function getScreenshots() {
  return readJSON(SCREENSHOTS_FILE);
}

function addScreenshotRecord(record) {
  const records = getScreenshots();
  records.push(record);
  writeJSON(SCREENSHOTS_FILE, records);
  return record;
}

function getScreenshotsForEmployee(employeeId, date) {
  let records = getScreenshots().filter((r) => r.employeeId === employeeId);
  if (date) records = records.filter((r) => r.capturedAt.startsWith(date));
  return records.sort((a, b) => new Date(b.capturedAt) - new Date(a.capturedAt));
}

// ---------- Activity (app/window usage) ----------
function getActivity() {
  return readJSON(ACTIVITY_FILE);
}

function addActivityEvents(events) {
  const records = getActivity();
  records.push(...events);
  writeJSON(ACTIVITY_FILE, records);
  return events;
}

function getActivityForEmployee(employeeId, date) {
  let records = getActivity().filter((r) => r.employeeId === employeeId);
  if (date) records = records.filter((r) => r.start.startsWith(date));
  return records.sort((a, b) => new Date(b.start) - new Date(a.start));
}

// ---------- Browsing (URL visits) ----------
function getBrowsing() {
  return readJSON(BROWSING_FILE);
}

function addBrowsingEvents(events) {
  const records = getBrowsing();
  records.push(...events);
  writeJSON(BROWSING_FILE, records);
  return events;
}

function getBrowsingForEmployee(employeeId, date) {
  let records = getBrowsing().filter((r) => r.employeeId === employeeId);
  if (date) records = records.filter((r) => r.visitedAt.startsWith(date));
  return records.sort((a, b) => new Date(b.visitedAt) - new Date(a.visitedAt));
}

// ---------- Productivity categories ----------
function getCategories() {
  return readJSON(CATEGORIES_FILE);
}

function saveCategories(categories) {
  writeJSON(CATEGORIES_FILE, categories);
}

function addCategory(category) {
  const categories = getCategories();
  categories.push(category);
  saveCategories(categories);
  return category;
}

function deleteCategory(id) {
  const categories = getCategories().filter((c) => c.id !== id);
  saveCategories(categories);
}

module.exports = {
  init,
  getEmployees,
  getEmployeeByEmail,
  getEmployeeById,
  getEmployeeByAgentToken,
  setAgentToken,
  revokeAgentToken,
  addEmployee,
  saveEmployees,
  getAttendance,
  getOpenSessionForEmployee,
  addAttendanceRecord,
  updateAttendanceRecord,
  getAttendanceForEmployee,
  getScreenshots,
  addScreenshotRecord,
  getScreenshotsForEmployee,
  getActivity,
  addActivityEvents,
  getActivityForEmployee,
  getBrowsing,
  addBrowsingEvents,
  getBrowsingForEmployee,
  getCategories,
  saveCategories,
  addCategory,
  deleteCategory,
  SCREENSHOTS_DIR,
};
