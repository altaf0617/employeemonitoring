// Run with: npm run seed
// Creates an initial admin account and a couple of demo employees.
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const db = require("./db");

db.init();

const usersToCreate = [
  { name: "Admin", email: "admin@office.com", password: "admin123", role: "admin" },
  { name: "Ali Raza", email: "ali@office.com", password: "password123", role: "employee" },
  { name: "Sara Khan", email: "sara@office.com", password: "password123", role: "employee" },
];

const existing = db.getEmployees();

usersToCreate.forEach((u) => {
  if (existing.find((e) => e.email === u.email)) {
    console.log(`Skipping ${u.email} (already exists)`);
    return;
  }
  db.addEmployee({
    id: crypto.randomUUID(),
    name: u.name,
    email: u.email,
    passwordHash: bcrypt.hashSync(u.password, 10),
    role: u.role,
    createdAt: new Date().toISOString(),
  });
  console.log(`Created ${u.role}: ${u.email} / ${u.password}`);
});

console.log("\nSeeding complete. Login credentials:");
usersToCreate.forEach((u) => console.log(`  ${u.email} / ${u.password} (${u.role})`));
