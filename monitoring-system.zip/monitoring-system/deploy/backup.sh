#!/bin/bash
# Office Monitoring System - daily backup script.
#
# Backs up the entire data/ folder (employees, attendance, screenshots,
# activity, browsing, categories - literally the whole database) to a
# timestamped tarball, keeps a rolling window of recent backups locally,
# and deletes old ones so disk doesn't fill up silently.
#
# Install this to run daily via cron - see the setup instructions at the
# bottom of this file.

set -euo pipefail

# ---------------- Configuration - edit these for your setup ----------------

APP_DIR="/opt/monitoring-system"                # where server.js and data/ live
BACKUP_DIR="/opt/monitoring-system-backups"     # where backups are stored
KEEP_DAYS=30                                     # delete local backups older than this

# Optional: set this to an rclone remote (e.g. "s3:my-bucket/monitoring-backups")
# to also copy backups off this machine. Leave empty to skip offsite backup.
# Requires `rclone` installed and configured (`rclone config`) separately.
OFFSITE_REMOTE=""

# -----------------------------------------------------------------------

TIMESTAMP=$(date +%Y-%m-%d_%H-%M-%S)
BACKUP_FILE="$BACKUP_DIR/monitoring-data_$TIMESTAMP.tar.gz"

mkdir -p "$BACKUP_DIR"

if [ ! -d "$APP_DIR/data" ]; then
  echo "ERROR: $APP_DIR/data does not exist. Is APP_DIR set correctly?" >&2
  exit 1
fi

echo "Backing up $APP_DIR/data -> $BACKUP_FILE"
tar -czf "$BACKUP_FILE" -C "$APP_DIR" data

BACKUP_SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
echo "Backup created: $BACKUP_FILE ($BACKUP_SIZE)"

# Delete local backups older than KEEP_DAYS
echo "Removing local backups older than $KEEP_DAYS days..."
find "$BACKUP_DIR" -name "monitoring-data_*.tar.gz" -mtime "+$KEEP_DAYS" -print -delete

# Optional offsite copy
if [ -n "$OFFSITE_REMOTE" ]; then
  if command -v rclone >/dev/null 2>&1; then
    echo "Copying to offsite remote: $OFFSITE_REMOTE"
    rclone copy "$BACKUP_FILE" "$OFFSITE_REMOTE"
  else
    echo "WARNING: OFFSITE_REMOTE is set but rclone is not installed. Skipping offsite copy." >&2
  fi
fi

echo "Backup complete."

# ---------------- Setup instructions ----------------
#
# 1. Save this file as, e.g., /opt/monitoring-system-backups/backup.sh
# 2. Make it executable:
#      chmod +x /opt/monitoring-system-backups/backup.sh
# 3. Edit APP_DIR / BACKUP_DIR / KEEP_DAYS above to match your setup.
# 4. Test it manually once:
#      /opt/monitoring-system-backups/backup.sh
#    Confirm a .tar.gz appears in BACKUP_DIR.
# 5. Schedule it to run daily via cron:
#      sudo crontab -e
#    Add this line (runs every day at 2:30am):
#      30 2 * * * /opt/monitoring-system-backups/backup.sh >> /var/log/monitoring-backup.log 2>&1
#
# To restore from a backup:
#   sudo systemctl stop monitoring-system
#   cd /opt/monitoring-system
#   mv data data.bad                     # keep the broken one just in case
#   tar -xzf /opt/monitoring-system-backups/monitoring-data_TIMESTAMP.tar.gz -C /opt/monitoring-system
#   sudo systemctl start monitoring-system
