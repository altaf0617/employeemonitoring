#!/bin/bash
# Office Monitoring System - firewall setup (ufw).
#
# Opens only what's needed: SSH (so you don't lock yourself out), and
# HTTP/HTTPS for Caddy (80 is needed for certificate issuance/renewal,
# not just 443). Port 4000 (the Node app itself) is deliberately NOT
# opened - it should only be reachable via Caddy on localhost, not
# directly from the internet.

set -euo pipefail

echo "Configuring firewall..."
sudo ufw allow 22/tcp    comment 'SSH'
sudo ufw allow 80/tcp    comment 'HTTP - required for Caddy cert renewal'
sudo ufw allow 443/tcp   comment 'HTTPS'

echo ""
echo "About to enable ufw. Make sure SSH (22/tcp) is allowed above, or you"
echo "may lock yourself out of this server."
read -p "Continue and enable the firewall now? [y/N] " confirm

if [[ "$confirm" =~ ^[Yy]$ ]]; then
  sudo ufw --force enable
  sudo ufw status verbose
else
  echo "Firewall rules were added but not enabled. Run 'sudo ufw enable' when ready."
fi
