# Deployment files

Everything here supports the step-by-step deployment already covered in
conversation. Quick reference / checklist:

## Files in this folder

| File | Purpose | Where it goes |
|---|---|---|
| `monitoring-system.service` | Keeps the backend running, auto-restarts on crash/reboot | `/etc/systemd/system/` |
| `Caddyfile` | Automatic HTTPS reverse proxy | `/etc/caddy/Caddyfile` |
| `setup-firewall.sh` | Opens only 22/80/443, keeps 4000 internal-only | run once on the server |
| `backup.sh` | Daily backup of the `data/` folder, with rotation | `/opt/monitoring-system-backups/`, run via cron |

## Checklist, in order

- [ ] Server provisioned (cloud VM or office machine with a reachable public IP)
- [ ] Confirmed **not** behind CGNAT, if self-hosting from an office (compare
      `whatismyip.com` against your router's WAN IP page)
- [ ] Domain/subdomain DNS pointed at the server's public IP (or Dynamic DNS
      configured, if the IP isn't static)
- [ ] Node.js installed
- [ ] Project copied to `/opt/monitoring-system`
- [ ] `npm install` + `npm run seed` run once
- [ ] Default admin password changed (see conversation above for the bcrypt-hash method)
- [ ] `monitoring-system.service` copied in, `JWT_SECRET` and `User=` edited, service enabled+started
- [ ] `setup-firewall.sh` run (opens 22/80/443 only)
- [ ] Caddy installed, `Caddyfile` copied in with your real domain, restarted
- [ ] Confirmed `https://your-domain` loads with a valid padlock
- [ ] `backup.sh` copied to `/opt/monitoring-system-backups/`, made executable,
      `APP_DIR`/`BACKUP_DIR` edited, tested manually once, then scheduled via cron
- [ ] Agent's `DEFAULT_SERVER_URL` (or each employee's `config.json`) updated
      to the new `https://your-domain` address, `.exe` rebuilt if needed

Each file has its own detailed setup instructions in a comment block at the
bottom - open the file itself for the exact commands.

## After this is all running

Things worth coming back to once the basics are live and stable:
- A real "change admin password" UI instead of the manual bcrypt-hash workaround
- Screenshot/data retention policy (auto-delete after N days) - not built yet
- Offsite backup destination (`backup.sh` supports this via `rclone` - just needs configuring)
- Restricting the dashboard to known IPs/VPN if none of your admins are ever remote
