// Categorizes activity/browsing events as productive/unproductive/neutral
// based on admin-defined category rules, and builds aggregated reports.

const db = require("./db");

function normalize(str) {
  return (str || "").toLowerCase().trim();
}

function categorizeApp(appName) {
  const categories = db.getCategories().filter((c) => c.type === "app");
  const norm = normalize(appName);
  const match = categories.find((c) => norm.includes(normalize(c.name)));
  return match ? match.label : "uncategorized";
}

function categorizeDomain(domain) {
  const categories = db.getCategories().filter((c) => c.type === "domain");
  const norm = normalize(domain);
  const match = categories.find((c) => norm.includes(normalize(c.name)));
  return match ? match.label : "uncategorized";
}

function durationMinutes(startISO, endISO) {
  return Math.max(0, (new Date(endISO) - new Date(startISO)) / 60000);
}

function buildProductivityReport(employeeId, date) {
  const activity = db.getActivityForEmployee(employeeId, date);
  const browsing = db.getBrowsingForEmployee(employeeId, date);

  const totals = { productive: 0, unproductive: 0, neutral: 0, uncategorized: 0, idle: 0 };
  const appBreakdown = {};
  const domainBreakdown = {};

  for (const ev of activity) {
    const mins = durationMinutes(ev.start, ev.end);
    if (ev.isIdle) {
      totals.idle += mins;
      continue;
    }
    const label = categorizeApp(ev.appName);
    totals[label] = (totals[label] || 0) + mins;
    appBreakdown[ev.appName] = (appBreakdown[ev.appName] || 0) + mins;
  }

  for (const ev of browsing) {
    const mins = ev.durationMinutes != null ? ev.durationMinutes : 0.5;
    const label = categorizeDomain(ev.domain);
    totals[label] = (totals[label] || 0) + mins;
    domainBreakdown[ev.domain] = (domainBreakdown[ev.domain] || 0) + mins;
  }

  const round1 = (n) => Math.round(n * 10) / 10;
  const totalTracked = Object.values(totals).reduce((a, b) => a + b, 0);

  const topApps = Object.entries(appBreakdown)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([name, minutes]) => ({ name, minutes: round1(minutes), label: categorizeApp(name) }));

  const topSites = Object.entries(domainBreakdown)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([name, minutes]) => ({ name, minutes: round1(minutes), label: categorizeDomain(name) }));

  return {
    employeeId,
    date,
    totals: {
      productiveMinutes: round1(totals.productive),
      unproductiveMinutes: round1(totals.unproductive),
      neutralMinutes: round1(totals.neutral),
      uncategorizedMinutes: round1(totals.uncategorized),
      idleMinutes: round1(totals.idle),
      totalTrackedMinutes: round1(totalTracked),
    },
    productivityScore:
      totalTracked > 0 ? round1((totals.productive / (totalTracked - totals.idle || 1)) * 100) : 0,
    topApps,
    topSites,
  };
}

module.exports = {
  categorizeApp,
  categorizeDomain,
  buildProductivityReport,
};
