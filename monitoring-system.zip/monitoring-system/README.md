# Office Monitoring System

A full employee monitoring system: check-in/check-out, screenshots,
productivity tracking, and browser/URL tracking — similar in spirit to
ActivTrak/Teramind/TimeChamp. Built as a backend + web admin dashboard +
Electron desktop agent.

## What's included

```
monitoring-system/
├── server.js            Express API (auth, attendance, agent ingestion, admin/reports)
├── db.js                JSON-file data layer (employees, attendance, screenshots, activity, browsing, categories)
├── productivity.js       Productivity scoring / report aggregation
├── seed.js               Creates demo admin + employee accounts
├── public/
│   ├── index.html         Employee check-in/check-out page
│   ├── admin.html          Admin: attendance dashboard + employee/agent setup
│   ├── monitoring.html     Admin: productivity reports, screenshot gallery, category rules
│   └── style.css
├── agent/                 Electron desktop agent (see agent/README.md)
│   ├── main.js
│   ├── login.html
│   ├── admin-unlock.html
│   ├── installer/          Watchdog script + NSIS install hooks
│   └── src/
│       ├── apiClient.js
│       ├── screenshotCapture.js
│       ├── activityTracker.js
│       ├── browserHistoryTracker.js
│       └── config.js
└── deploy/                 Production deployment files (see deploy/README.md)
    ├── monitoring-system.service   systemd unit
    ├── Caddyfile                    HTTPS reverse proxy config
    ├── setup-firewall.sh
    └── backup.sh
```

## Setup — backend + web dashboard

```bash
npm install
npm run seed      # creates demo accounts (see below)
npm start         # runs on http://localhost:4000
```

- Employee check-in page: `http://localhost:4000`
- Admin attendance dashboard: `http://localhost:4000/admin.html`
- Admin monitoring dashboard (productivity/screenshots/categories): `http://localhost:4000/monitoring.html`

### Demo accounts (created by `npm run seed`)

| Role     | Email             | Password     |
|----------|-------------------|--------------|
| Admin    | admin@office.com  | admin123     |
| Employee | ali@office.com    | password123  |
| Employee | sara@office.com   | password123  |

**Change these before deploying.**

## Setup — desktop agent

See [`agent/README.md`](agent/README.md) for full setup, the zero-touch
install flow, permissions, and packaging instructions.

## Deploying to production (server hosting, HTTPS, backups)

See [`deploy/README.md`](deploy/README.md) for the full checklist: systemd
service, Caddy HTTPS reverse proxy, firewall setup, and automated backups.

## How the pieces fit together

1. Admin adds the employee in the web dashboard, then generates an agent
   config from "Employees & agent setup" — a `config.json` with a unique,
   revocable device token (not the employee's password).
2. IT installs the agent `.exe` on that employee's machine and drops
   `config.json` in the install folder. Agent reads it and signs in
   silently — **no login screen, nothing for the employee to enter.**
3. Agent captures a screenshot every ~7 min, tracks the active app/window
   (idle-aware), and reads local browser history every 5 min to log URL
   visits — all uploaded to the backend under that employee's account.
4. Employee can check in/out from the tray menu or the web page — same
   attendance system either way.
5. Admin reviews everything in `monitoring.html`: productivity score per
   employee/day, top apps and sites, screenshot gallery, and a company-wide
   daily overview. Category rules (which apps/domains count as
   productive/unproductive/neutral) are managed there too.

## API reference

### Auth & employees
| Method | Path | Who | Description |
|---|---|---|---|
| POST | `/api/auth/login` | anyone | password login: `{email, password}` → `{token, user}` |
| POST | `/api/auth/device-login` | anyone (needs valid token) | agent zero-touch login: `{agentToken}` → `{token, user}` |
| GET | `/api/auth/me` | any user | current user info |
| POST | `/api/employees` | admin | create employee |
| GET | `/api/employees` | admin | list employees (includes `agentEnrolled` status) |
| POST | `/api/admin/employees/:id/agent-token` | admin | generate/regenerate an employee's device token |
| POST | `/api/admin/employees/:id/agent-token/revoke` | admin | revoke an employee's device token |

### Attendance
| Method | Path | Who | Description |
|---|---|---|---|
| POST | `/api/attendance/check-in` | any user | check in |
| POST | `/api/attendance/check-out` | any user | check out |
| GET | `/api/attendance/status` | any user | current session status |
| GET | `/api/attendance/my-history` | any user | own attendance records |
| GET | `/api/admin/attendance` | admin | all records, filter by `?employeeId=` / `?date=` |
| GET | `/api/admin/summary` | admin | per-employee status + hours |

### Agent ingestion (used by the desktop agent)
| Method | Path | Description |
|---|---|---|
| POST | `/api/agent/screenshot` | `{imageBase64, capturedAt}` |
| POST | `/api/agent/activity` | `{events: [{appName, windowTitle, start, end, isIdle}]}` |
| POST | `/api/agent/browsing` | `{events: [{domain, url, title, visitedAt, durationMinutes}]}` |

### Admin: monitoring data & reports
| Method | Path | Description |
|---|---|---|
| GET | `/api/admin/screenshots?employeeId=&date=` | screenshot list |
| GET | `/api/admin/activity?employeeId=&date=` | raw activity sessions |
| GET | `/api/admin/browsing?employeeId=&date=` | raw browsing events |
| GET | `/api/admin/productivity-report?employeeId=&date=` | one employee's report |
| GET | `/api/admin/productivity-report/company?date=` | all employees, one date |
| GET/POST/DELETE | `/api/admin/categories` | manage productive/unproductive/neutral rules |

## Before you deploy this for real

1. **Set a strong `JWT_SECRET`** via environment variable — don't ship the
   default in `server.js`. (`deploy/monitoring-system.service` has a spot for this.)
2. **Run behind HTTPS.** (`deploy/Caddyfile` handles this automatically.)
3. **Employee notice & consent — read this carefully.** This system captures
   screenshots, application usage, and browsing history. In most
   jurisdictions that requires disclosing what's tracked, and often written
   consent; specifics vary a lot by country/state (some restrict
   screenshot/keystroke-level monitoring specifically, some require
   consent banners, some require data retention limits). The agent's login
   screen shows a short notice as a starting point, but get this reviewed
   by HR/legal for wherever your employees are located before rollout —
   this genuinely isn't optional in a lot of places.
4. **Move off JSON-file storage before production scale.** Screenshot/
   activity/browsing data grows fast — plan a Postgres migration (or
   similar) once you're past pilot/demo stage, especially past a handful of
   employees generating real all-day data.
5. **Screenshot storage**: images are saved to `data/screenshot-images/` on
   the server's disk. Plan for storage growth and a retention/deletion
   policy (e.g., auto-delete after 30/60/90 days) — this isn't implemented
   yet.
6. **Back up your data directory** regularly — `deploy/backup.sh` handles
   this via a daily cron job.

## Not yet built (natural next steps)

- Screenshot/data retention & auto-deletion policy
- Weekly/monthly rollup reports (currently per-day)
- Alerts (e.g., notify admin if productivity drops below a threshold)
- Bulk employee import (CSV)
- Employee-facing view of their own productivity data (currently admin-only)
- A proper "change admin password" UI (currently requires manually editing `data/employees.json`)

Want any of these next? Just ask.
