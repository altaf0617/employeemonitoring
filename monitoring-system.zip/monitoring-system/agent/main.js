const { app, BrowserWindow, Tray, Menu, ipcMain, Notification } = require("electron");
const path = require("path");
const Store = require("electron-store");

const ApiClient = require("./src/apiClient");
const { captureScreenshot } = require("./src/screenshotCapture");
const ActivityTracker = require("./src/activityTracker");
const BrowserHistoryTracker = require("./src/browserHistoryTracker");
const config = require("./src/config");

// ---------------- Configuration ----------------
// See src/config.js for how SERVER_URL is resolved (env var, config.json, or default).
const SERVER_URL = config.serverUrl;
const SCREENSHOT_INTERVAL_MS = 7 * 60 * 1000; // ~7 min, within the 5-10 min range
const BROWSER_HISTORY_POLL_MS = 5 * 60 * 1000;

const store = new Store(); // persists auth token / browser-history state locally between launches

// Prevent duplicate instances (relevant since the app auto-launches at login)
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
}

if (process.platform === "win32") {
  app.setAppUserModelId("com.yourcompany.officemonitor");
}

let tray = null;
let loginWindow = null;
let api = new ApiClient(SERVER_URL);
let activityTracker = null;
let browserHistoryTracker = null;
let screenshotTimer = null;
let monitoringActive = false;

// ---------------- Login window ----------------

function openLoginWindow() {
  loginWindow = new BrowserWindow({
    width: 380,
    height: 480,
    resizable: false,
    title: "Office Monitor - Sign in",
    webPreferences: {
      nodeIntegration: true, // simple internal login.html, no untrusted content
      contextIsolation: false,
    },
  });
  loginWindow.setMenuBarVisibility(false);
  loginWindow.loadFile(path.join(__dirname, "login.html"));
  loginWindow.on("closed", () => {
    loginWindow = null;
  });
}

ipcMain.handle("agent:login", async (event, { email, password }) => {
  try {
    const data = await api.login(email, password);
    store.set("token", data.token);
    store.set("user", data.user);
    startMonitoring();
    if (loginWindow) loginWindow.close();
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// ---------------- Admin unlock (IT-only local controls) ----------------
// Employees have no in-app way to stop monitoring. Pausing, signing this
// device out, or quitting the agent all require a real admin login,
// verified against the backend - not a local password or bypass.

let adminUnlockWindow = null;

function openAdminUnlockWindow() {
  if (adminUnlockWindow) {
    adminUnlockWindow.focus();
    return;
  }
  adminUnlockWindow = new BrowserWindow({
    width: 400,
    height: 420,
    resizable: false,
    title: "Office Monitor - IT Administration",
    webPreferences: { nodeIntegration: true, contextIsolation: false },
  });
  adminUnlockWindow.setMenuBarVisibility(false);
  adminUnlockWindow.loadFile(path.join(__dirname, "admin-unlock.html"));
  adminUnlockWindow.on("closed", () => {
    adminUnlockWindow = null;
  });
}

ipcMain.handle("agent:verifyAdmin", async (event, { email, password }) => {
  try {
    // Use a throwaway client so we never touch the agent's own active session token.
    const checkClient = new ApiClient(SERVER_URL);
    const data = await checkClient.login(email, password);
    if (data.user.role !== "admin") {
      return { ok: false, error: "This account is not an admin." };
    }
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

ipcMain.handle("agent:adminSignOut", () => {
  stopMonitoring();
  store.delete("token");
  store.delete("user");
  api.clearToken();
  if (adminUnlockWindow) adminUnlockWindow.close();
  openLoginWindow();
  updateTray();
});

ipcMain.handle("agent:adminQuit", () => {
  stopMonitoring();
  if (adminUnlockWindow) adminUnlockWindow.close();
  app.exit(0);
});

// ---------------- Tray ----------------

function buildTrayMenu() {
  const user = api.user;
  const template = [
    { label: user ? `Signed in as ${user.name}` : "Not signed in", enabled: false },
    { type: "separator" },
    {
      label: monitoringActive ? "Monitoring: Active" : "Monitoring: Paused",
      enabled: false,
    },
    { type: "separator" },
    {
      label: "Check In",
      click: async () => {
        try {
          await api.checkIn();
        } catch (err) {
          console.error("Check-in failed:", err.message);
        }
      },
    },
    {
      label: "Check Out",
      click: async () => {
        try {
          await api.checkOut();
        } catch (err) {
          console.error("Check-out failed:", err.message);
        }
      },
    },
    { type: "separator" },
    {
      label: "IT administration...",
      click: () => openAdminUnlockWindow(),
    },
  ];
  return Menu.buildFromTemplate(template);
}

function updateTray() {
  if (!tray) return;
  tray.setContextMenu(buildTrayMenu());
  tray.setToolTip(monitoringActive ? "Office Monitor - Active" : "Office Monitor - Signed out");
}

function enableAutoLaunch() {
  // Starts the agent automatically when the user logs into Windows, with
  // no window flashing on screen - it goes straight to the tray.
  if (process.platform === "win32") {
    app.setLoginItemSettings({
      openAtLogin: true,
      args: ["--auto-launched"],
    });
  }
}

function showStartupNotice() {
  // Required disclosure, not optional: a brief native OS notification each
  // time monitoring begins for the session, so the tray icon isn't the only
  // signal that this is running. Don't remove this - most jurisdictions
  // require employees to be able to tell monitoring software is active.
  if (Notification.isSupported()) {
    new Notification({
      title: "Office Monitor",
      body: "Monitoring is now active for this session.",
      silent: true,
    }).show();
  }
}

function createTray() {
  tray = new Tray(path.join(__dirname, "tray-icon.png"));
  updateTray();
}

// ---------------- Monitoring orchestration ----------------

async function takeAndUploadScreenshot() {
  try {
    const dataUrl = await captureScreenshot();
    await api.uploadScreenshot(dataUrl, new Date().toISOString());
  } catch (err) {
    console.error("Screenshot capture/upload failed:", err.message);
  }
}

function startMonitoring() {
  if (monitoringActive) return;
  monitoringActive = true;
  showStartupNotice();

  // Screenshots
  takeAndUploadScreenshot();
  screenshotTimer = setInterval(takeAndUploadScreenshot, SCREENSHOT_INTERVAL_MS);

  // Active window / idle tracking
  activityTracker = new ActivityTracker({
    onFlush: async (events) => {
      try {
        await api.uploadActivity(events);
      } catch (err) {
        console.error("Activity upload failed:", err.message);
      }
    },
  });
  activityTracker.start();

  // Browser history (agent-level URL tracking, no extension)
  browserHistoryTracker = new BrowserHistoryTracker({
    persistedLastSeen: store.get("browserHistoryLastSeen"),
    onLastSeenChange: (lastSeen) => store.set("browserHistoryLastSeen", lastSeen),
    onEvents: async (events) => {
      try {
        await api.uploadBrowsing(events);
      } catch (err) {
        console.error("Browsing upload failed:", err.message);
      }
    },
  });
  browserHistoryTracker.start(BROWSER_HISTORY_POLL_MS);

  updateTray();
}

function stopMonitoring() {
  monitoringActive = false;
  if (screenshotTimer) clearInterval(screenshotTimer);
  if (activityTracker) activityTracker.stop();
  if (browserHistoryTracker) browserHistoryTracker.stop();
  updateTray();
}

// ---------------- App lifecycle ----------------

app.whenReady().then(async () => {
  createTray();
  enableAutoLaunch();

  // Zero-touch path: config.json (generated by an admin, dropped in the
  // install folder by IT) contains an agentToken - sign in silently, no
  // login window shown at all.
  if (config.agentToken) {
    try {
      await api.deviceLogin(config.agentToken);
      startMonitoring();
      updateTray();
      return;
    } catch (err) {
      console.error("Device-token login failed:", err.message);
      if (Notification.isSupported()) {
        new Notification({
          title: "Office Monitor",
          body: "Couldn't authenticate with the configured agent token. Contact IT.",
        }).show();
      }
      // Falls through to the manual-login path below as a fallback, in
      // case config.json is stale (e.g. token was revoked) and someone
      // needs to sign in by hand to diagnose it.
    }
  }

  // Fallback: previously saved session from a manual login
  const savedToken = store.get("token");
  const savedUser = store.get("user");

  if (savedToken && savedUser) {
    api.setToken(savedToken, savedUser);
    try {
      await api.me(); // validate token is still good
      startMonitoring();
    } catch (err) {
      store.delete("token");
      store.delete("user");
      openLoginWindow();
    }
  } else {
    openLoginWindow();
  }

  updateTray();
});

// Keep running in the tray on macOS/Windows even with no windows open
app.on("window-all-closed", (e) => {
  e.preventDefault();
});

// On system shutdown/logoff, Windows terminates the process automatically -
// nothing needs to be built to make the agent "stop" then. This just makes
// sure we don't lose the last few minutes of tracked activity: flush
// whatever's pending and wait (briefly) for the upload before actually
// exiting, so it's not lost in an unsent HTTP request when the OS kills us.
let quittingCleanly = false;
app.on("before-quit", async (e) => {
  if (quittingCleanly || !activityTracker) return;
  e.preventDefault();
  quittingCleanly = true;
  const timeout = new Promise((resolve) => setTimeout(resolve, 1500)); // don't hang shutdown if offline
  await Promise.race([activityTracker.flush(), timeout]);
  app.quit();
});
