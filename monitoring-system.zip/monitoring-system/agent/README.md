# Office Monitor — Desktop Agent

Electron app that runs on each employee's machine and reports to the backend
server: periodic screenshots, active-application tracking, idle detection,
and browser history (URL) tracking — all without requiring a browser
extension.

## How it works

- **Screenshots**: captured every ~7 minutes via Electron's `desktopCapturer`,
  uploaded as base64 to `/api/agent/screenshot`.
- **Activity tracking**: polls the foreground app/window every 5 seconds
  using `active-win`, coalesces into sessions, uploads batches every 5
  minutes to `/api/agent/activity`. Idle time (no input for 2+ minutes, via
  Electron's `powerMonitor`) is tracked separately and excluded from
  productive time.
- **Browser history / URL tracking**: every 5 minutes, reads the local
  history database that Chrome/Edge/Brave/Firefox already maintain on disk,
  extracts new visits since the last read, uploads them. Uses `sql.js`
  (pure JS/WASM SQLite) — no native compilation needed.
- **Check-in/out**: available from the tray menu, reuses the check-in/out
  system already built.

## Setup — zero-touch install (recommended for real deployment)

Employees never see a login screen or type any credentials. Here's the flow:

1. **Admin adds the employee** in the web dashboard (`admin.html` → "Add employee") — same as before.
2. **Admin generates an agent config** for that employee: `admin.html` → "Employees & agent setup" → "Generate & download" next to their name. This downloads a `config.json` containing a unique, revocable device token — not their password.
3. **IT installs the agent** on that employee's machine (see "Building the Windows .exe" below), then places the downloaded `config.json` in the same folder as the installed exe (typically `C:\Program Files\Office Monitor\config.json`).
4. **Done.** On launch, the agent reads `config.json`, signs in silently using the device token, and starts monitoring immediately. No password, no prompt, nothing for the employee to do.

Each employee needs their *own* `config.json` (it's tied to their account via the device token) — don't reuse one file across multiple machines/employees. If a token is compromised or an employee leaves, revoke it from the same dashboard section; the agent on that machine will stop being able to authenticate.

`config.json` format:
```json
{
  "serverUrl": "http://your-server:4000",
  "employeeId": "...",
  "agentToken": "..."
}
```

### Fallback: manual login

If no `config.json` is present (or its token gets revoked), the agent falls
back to showing a normal email/password login window — useful for testing,
or for a one-off machine you haven't provisioned yet. Both paths use the
exact same backend and produce the exact same monitoring behavior once
signed in.

## Setup — local development / testing

```bash
cd agent
npm install
```

Set the backend URL (defaults to `http://localhost:4000` for local testing):

```bash
export MONITOR_SERVER_URL=https://your-server.example.com
npm start
```

Without a `config.json` present, this shows the manual login window on
first launch. The token is saved locally (via `electron-store`) so it
doesn't need to be entered again on next launch.

## Building the Windows .exe

**Run this on a machine with normal internet access** — it downloads a
prebuilt Windows binary for the active-window-tracking dependency, which
needs to reach GitHub's release CDN. (You don't need to be on Windows to
build it — electron-builder can cross-compile the Windows target from
macOS or Linux too, though Linux needs Wine installed for the installer step.)

```bash
cd agent
npm install
npm run build:win
```

This produces two files in `agent/dist/`:
- **`Office Monitor Setup 1.0.0.exe`** — NSIS installer. One-click, installs
  per-machine (not per-user), adds a Start Menu shortcut, and launches the
  app after install. No desktop shortcut is created.
- **`Office Monitor 1.0.0.exe`** — portable version, no installation, just run it.

Before building, set the real backend URL so you don't have to configure
each machine individually — edit `DEFAULT_SERVER_URL` in `src/config.js`,
or ship a `config.json` (see above — this is normally already handled by
the zero-touch flow).

### Deploying quietly across a fleet

The installer supports NSIS's standard silent-install switch, which is the
normal way IT tools (GPO, Intune, PDQ Deploy, etc.) push software without a
user needing to click through anything:

```
"Office Monitor Setup 1.0.0.exe" /S
```

This runs a normal, disclosed install — the app still ends up with a tray
icon and shows a startup notification on first launch of each session; only
the *installation step* is unattended. That's a distinct thing from hiding
the app from the employee once it's running (see below).

### About config.json

This is the same `config.json` described in "Setup — zero-touch install"
above — it's generated per-employee from the admin dashboard and normally
already contains `agentToken` + `employeeId` for silent sign-in. You can
also hand-write one with just `serverUrl` (no `agentToken`) if you want a
machine to fall back to the manual login screen but still point at a
non-default server — useful for a shared/kiosk-style machine, or staging
vs. production environments during testing.

## Preventing employees from stopping it themselves

Three layers, none of them tricks — all standard, inspectable Windows tooling:

1. **No in-app way to stop it.** The tray menu has no Quit or Sign Out.
   The only local control is "IT administration...", which requires a real
   admin login (checked against your backend, same as the web dashboard) —
   not a local password, not a bypass. A non-admin employee account simply
   can't get past that screen. Note: on a zero-touch machine (one set up
   with `config.json`), "Sign out this device" only pauses monitoring
   until the next restart — since the device token in `config.json` is
   still valid, the agent will silently re-authenticate on relaunch. To
   actually stop a specific machine, revoke that employee's agent token
   from the dashboard (or delete `config.json` from the install folder).
2. **Per-machine install.** The NSIS installer installs for all users and
   requires admin rights to uninstall via Programs & Features — a standard
   employee account can't remove it that way.
3. **Watchdog scheduled task** (`installer/watchdog.ps1` +
   `installer/custom.nsh`). Registered automatically during install, it
   checks every 5 minutes whether the agent is running and relaunches it
   if not. Fully readable, no obfuscation — any admin can open the `.ps1`
   file and see exactly what it does.

**What this does and doesn't actually guarantee, honestly:**

- An employee *can* still kill the running process via Task Manager at any
  moment — Windows lets any account do that to its own processes,
  admin or not. There's no legitimate way to prevent that at the
  application layer without doing things I'm not willing to build (see
  below). The watchdog just means it comes back within a few minutes,
  which in practice removes the point of doing it.
- The real thing making this actually hold up is **your employees using
  standard, non-admin Windows accounts** — that's an IT/account-policy
  decision on your end, not something this app can create. If employees
  have local admin rights, no application-layer measure will reliably
  stop them from removing monitoring software; that's just how Windows
  permissions work; the fix is the account policy, not the app.
- **Read the warning at the top of `installer/custom.nsh` before deploying
  via RMM/GPO.** The watchdog task is registered for whichever account
  runs the installer. If you install interactively per machine, that's
  correct. If you push it via a tool that installs under a SYSTEM account
  across a fleet, the task needs adjusting (`custom.nsh` explains how) or
  screenshots/activity tracking will silently stop working after a
  relaunch, because a SYSTEM-run process can't see the interactive
  desktop.
- **Test on one real machine before wide rollout.** I don't have a
  Windows environment to verify the Task Scheduler behavior end-to-end —
  the script and NSIS macros are correct as far as I can verify from the
  syntax/logic, but Windows service/session behavior has enough edge
  cases that I'd want you to confirm it on a real box first.

**What I won't add, regardless of the reasoning:** hiding the process
from Task Manager, blocking or hooking the "End Task" button, kernel-level
drivers, or anything designed to make the software hard to detect or
analyze. Those techniques are what separates "monitoring software" from
"malware" in most legal and technical definitions, and that's true
independent of whether the person asking has a legitimate business reason.

## Startup / shutdown lifecycle

- **Starts**: automatically at Windows login, no manual launch, no window
  flash — straight to the tray. (Technically "at login" rather than the
  literal boot moment before anyone's signed in — a true pre-login start
  can't access the screen for screenshots, which is a Windows session
  limitation, not a choice made here.)
- **Stops**: automatically at shutdown/logoff, same as any other running
  program — Windows terminates it, nothing extra needed. The agent does
  flush any pending tracked activity right before exiting (with a ~1.5s
  grace period) so the last few minutes aren't lost mid-upload.
- **Restarts don't create duplicate history.** The browser-history tracker
  persists how far it's read into each browser's history file, so a daily
  restart won't re-upload the same recent visits as if they were new.

## What "runs in the background" means here — and what it deliberately doesn't do

The agent auto-starts at Windows login (no manual launch needed) and shows
no window on startup — it goes straight to the tray. That's the "doesn't
get in anyone's way" part.

What it keeps, on purpose:
- **A visible tray icon** the whole time it's monitoring.
- **A native OS notification** ("Monitoring is now active for this
  session") each time it starts.
- **The login screen's monitoring notice.**
- **Visibility in Task Manager and the Windows uninstall list**, like any
  normal installed app.

I didn't build a version that strips these, and would encourage against
building one yourself even if a jurisdiction's specific rules technically
permit it — genuinely undisclosed employee monitoring is the kind of thing
that damages trust badly if/when discovered, on top of the legal exposure
in places that require notice. If your goal was just "employees shouldn't
have to babysit or manually launch this," the auto-start + tray-only
behavior above should already cover that.

## OS permissions you'll need to grant

- **macOS**: System Settings → Privacy & Security →
  - **Screen Recording** (required for screenshots AND for window titles on
    modern macOS — without this, `active-win` will still report the app name
    but not the window title)
  - **Accessibility** (required for `active-win` to function at all on some
    macOS versions)
- **Windows**: no special permissions needed for screenshots or activity
  tracking.
- **Linux**: screenshot capture and `active-win` work on X11. Wayland
  sessions have limited/no support for reading window titles from other
  apps — this is an OS-level restriction, not something the agent can work
  around. If your fleet runs Wayland, budget time to evaluate this before
  wide rollout.

## Known limitations (be upfront with your team about these)

- **Incognito/private browsing windows are not tracked** — this is by
  design (the browser itself doesn't write private browsing to its history
  file, so there's nothing for the agent to read). If you need to catch
  private-window usage, that requires a browser extension or system-level
  network monitoring instead, which is a materially bigger privacy footprint.
- **Only recognizes Chrome, Edge, Brave, and Firefox.** Safari, other
  Chromium forks, etc. aren't covered by the current history-file paths.
- **Wayland (Linux)** limits window-title visibility, as noted above.
- Screenshot/activity/URL data volume will grow quickly with 20-200
  employees — the JSON-file backend is fine to start, but plan to migrate
  to Postgres (or similar) before this becomes business-critical, especially
  for the browsing/activity tables.

## Before rolling this out

Company monitoring software crosses into legally sensitive territory in
most places — usually requiring employee notice and often written consent,
with specifics varying by state/country (and some jurisdictions restrict
screenshot/keystroke-level monitoring specifically). The login screen
includes a plain-language notice as a starting point, but this isn't a
substitute for a real policy reviewed by HR/legal for your jurisdiction.
