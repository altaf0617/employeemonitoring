// Resolves agent configuration, checked in this order:
//   1. MONITOR_SERVER_URL / MONITOR_AGENT_TOKEN environment variables (local dev/testing)
//   2. config.json placed next to the installed .exe - this is how a
//      zero-touch install works: an admin generates this file from the
//      dashboard (per employee) and IT drops it in the install directory.
//      If it contains agentToken + employeeId, the agent signs in silently
//      with no login screen at all.
//   3. DEFAULT_SERVER_URL below (edit this before building for production),
//      with no agentToken - the agent falls back to showing the manual
//      login screen.

const fs = require("fs");
const path = require("path");
const { app } = require("electron");

const DEFAULT_SERVER_URL = "https://your-monitoring-server.example.com";

function loadConfig() {
  let serverUrl = DEFAULT_SERVER_URL;
  let agentToken = null;
  let employeeId = null;

  try {
    // app.getPath("exe") -> .../Office Monitor/Office Monitor.exe
    // We look for config.json in that same install directory.
    const exeDir = path.dirname(app.getPath("exe"));
    const configPath = path.join(exeDir, "config.json");
    if (fs.existsSync(configPath)) {
      const parsed = JSON.parse(fs.readFileSync(configPath, "utf-8"));
      if (parsed.serverUrl) serverUrl = parsed.serverUrl;
      if (parsed.agentToken) agentToken = parsed.agentToken;
      if (parsed.employeeId) employeeId = parsed.employeeId;
    }
  } catch (err) {
    // fall through to defaults/env below
  }

  if (process.env.MONITOR_SERVER_URL) serverUrl = process.env.MONITOR_SERVER_URL;
  if (process.env.MONITOR_AGENT_TOKEN) agentToken = process.env.MONITOR_AGENT_TOKEN;

  return { serverUrl, agentToken, employeeId };
}

module.exports = loadConfig();
