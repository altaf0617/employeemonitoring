// Reads the browser's own local history database periodically to capture
// URL visits without needing a browser extension. This is the "agent-level"
// URL tracking approach: we don't intercept traffic, we just read the same
// history file the browser itself maintains.
//
// Chromium-based browsers (Chrome, Edge, Brave) lock their History file
// while running, so we copy it to a temp file before reading. Uses sql.js
// (pure JS/WASM SQLite) so there's no native module to compile.
//
// Limitations:
//  - Incognito/private windows are not recorded in the History file (by design).
//  - If a user runs a browser we don't recognize, its history won't be tracked.
//    URL tracking for those would need a browser extension instead.

const fs = require("fs");
const os = require("os");
const path = require("path");
const initSqlJs = require("sql.js");

const WEBKIT_EPOCH_OFFSET_MS = 11644473600000; // 1601-01-01 -> 1970-01-01, in ms

function webkitToISO(webkitMicros) {
  const ms = webkitMicros / 1000 - WEBKIT_EPOCH_OFFSET_MS;
  return new Date(ms).toISOString();
}

function firefoxMicrosToISO(micros) {
  return new Date(micros / 1000).toISOString();
}

function domainFromUrl(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "unknown";
  }
}

function getChromiumProfilePaths() {
  const home = os.homedir();
  const platform = process.platform;
  const candidates = [];

  if (platform === "darwin") {
    candidates.push(
      { name: "Chrome", file: path.join(home, "Library/Application Support/Google/Chrome/Default/History") },
      { name: "Edge", file: path.join(home, "Library/Application Support/Microsoft Edge/Default/History") },
      { name: "Brave", file: path.join(home, "Library/Application Support/BraveSoftware/Brave-Browser/Default/History") }
    );
  } else if (platform === "win32") {
    const localAppData = process.env.LOCALAPPDATA || path.join(home, "AppData/Local");
    candidates.push(
      { name: "Chrome", file: path.join(localAppData, "Google/Chrome/User Data/Default/History") },
      { name: "Edge", file: path.join(localAppData, "Microsoft/Edge/User Data/Default/History") },
      { name: "Brave", file: path.join(localAppData, "BraveSoftware/Brave-Browser/User Data/Default/History") }
    );
  } else {
    candidates.push(
      { name: "Chrome", file: path.join(home, ".config/google-chrome/Default/History") },
      { name: "Chromium", file: path.join(home, ".config/chromium/Default/History") },
      { name: "Edge", file: path.join(home, ".config/microsoft-edge/Default/History") },
      { name: "Brave", file: path.join(home, ".config/BraveSoftware/Brave-Browser/Default/History") }
    );
  }
  return candidates.filter((c) => fs.existsSync(c.file));
}

function getFirefoxProfilePaths() {
  const home = os.homedir();
  const platform = process.platform;
  let profilesRoot;

  if (platform === "darwin") {
    profilesRoot = path.join(home, "Library/Application Support/Firefox/Profiles");
  } else if (platform === "win32") {
    profilesRoot = path.join(process.env.APPDATA || "", "Mozilla/Firefox/Profiles");
  } else {
    profilesRoot = path.join(home, ".mozilla/firefox");
  }

  if (!profilesRoot || !fs.existsSync(profilesRoot)) return [];

  return fs
    .readdirSync(profilesRoot)
    .map((dir) => path.join(profilesRoot, dir, "places.sqlite"))
    .filter((p) => fs.existsSync(p))
    .map((file) => ({ name: "Firefox", file }));
}

class BrowserHistoryTracker {
  constructor({ onEvents, persistedLastSeen, onLastSeenChange } = {}) {
    this.onEvents = onEvents; // callback(events[])
    // key: browser file path -> last visit timestamp seen (raw, browser-native units)
    // Seeded from persistedLastSeen (if provided) so a restart doesn't
    // resend history we've already uploaded.
    this.lastSeen = persistedLastSeen ? { ...persistedLastSeen } : {};
    this.onLastSeenChange = onLastSeenChange; // callback(lastSeen) - called after each poll so the caller can persist it
    this.SQL = null;
    this.tmpDir = path.join(os.tmpdir(), "office-monitor-agent");
    if (!fs.existsSync(this.tmpDir)) fs.mkdirSync(this.tmpDir, { recursive: true });
  }

  async init() {
    this.SQL = await initSqlJs({
      locateFile: (file) => path.join(require.resolve("sql.js").replace(/[^/\\]+$/, ""), file),
    });
  }

  async pollChromium(profile) {
    const tmpCopy = path.join(this.tmpDir, `history_${Buffer.from(profile.file).toString("base64").slice(0, 20)}.sqlite`);
    try {
      fs.copyFileSync(profile.file, tmpCopy);
    } catch (err) {
      return [];
    }

    const buffer = fs.readFileSync(tmpCopy);
    const db = new this.SQL.Database(buffer);

    const lastSeenKey = profile.file;
    const since = this.lastSeen[lastSeenKey] || 0;

    const results = db.exec(
      `SELECT url, title, last_visit_time FROM urls WHERE last_visit_time > ${since} ORDER BY last_visit_time ASC LIMIT 500`
    );

    db.close();
    fs.unlinkSync(tmpCopy);

    if (!results.length) return [];

    const rows = results[0].values;
    let maxSeen = since;
    const events = rows.map(([url, title, lastVisitTime]) => {
      if (lastVisitTime > maxSeen) maxSeen = lastVisitTime;
      return {
        domain: domainFromUrl(url),
        url,
        title: title || "",
        visitedAt: webkitToISO(lastVisitTime),
        durationMinutes: null,
      };
    });
    this.lastSeen[lastSeenKey] = maxSeen;
    return events;
  }

  async pollFirefox(profile) {
    const tmpCopy = path.join(this.tmpDir, `places_${Buffer.from(profile.file).toString("base64").slice(0, 20)}.sqlite`);
    try {
      fs.copyFileSync(profile.file, tmpCopy);
    } catch (err) {
      return [];
    }

    const buffer = fs.readFileSync(tmpCopy);
    const db = new this.SQL.Database(buffer);

    const lastSeenKey = profile.file;
    const since = this.lastSeen[lastSeenKey] || 0;

    const results = db.exec(
      `SELECT p.url, p.title, h.visit_date
       FROM moz_historyvisits h JOIN moz_places p ON h.place_id = p.id
       WHERE h.visit_date > ${since} ORDER BY h.visit_date ASC LIMIT 500`
    );

    db.close();
    fs.unlinkSync(tmpCopy);

    if (!results.length) return [];

    const rows = results[0].values;
    let maxSeen = since;
    const events = rows.map(([url, title, visitDate]) => {
      if (visitDate > maxSeen) maxSeen = visitDate;
      return {
        domain: domainFromUrl(url),
        url,
        title: title || "",
        visitedAt: firefoxMicrosToISO(visitDate),
        durationMinutes: null,
      };
    });
    this.lastSeen[lastSeenKey] = maxSeen;
    return events;
  }

  async pollAll() {
    if (!this.SQL) await this.init();

    const allEvents = [];
    for (const profile of getChromiumProfilePaths()) {
      try {
        allEvents.push(...(await this.pollChromium(profile)));
      } catch (err) {
        // one browser's DB being weird shouldn't stop the others
      }
    }
    for (const profile of getFirefoxProfilePaths()) {
      try {
        allEvents.push(...(await this.pollFirefox(profile)));
      } catch (err) {
        // ignore
      }
    }

    if (allEvents.length && this.onEvents) {
      this.onEvents(allEvents);
    }
    if (this.onLastSeenChange) {
      this.onLastSeenChange(this.lastSeen);
    }
    return allEvents;
  }

  start(intervalMs = 5 * 60 * 1000) {
    this.timer = setInterval(() => this.pollAll(), intervalMs);
    this.pollAll();
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
  }
}

module.exports = BrowserHistoryTracker;
