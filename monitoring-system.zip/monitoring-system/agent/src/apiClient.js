// Talks to the monitoring backend. Uses Node's built-in fetch (Node 18+ / Electron 28+).

class ApiClient {
  constructor(baseUrl) {
    this.baseUrl = baseUrl;
    this.token = null;
    this.user = null;
    this.agentToken = null; // set after a successful deviceLogin, used to silently re-auth on expiry
  }

  setToken(token, user) {
    this.token = token;
    this.user = user;
  }

  clearToken() {
    this.token = null;
    this.user = null;
  }

  async request(path, options = {}, _isRetry = false) {
    const res = await fetch(this.baseUrl + path, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...(this.token ? { Authorization: "Bearer " + this.token } : {}),
        ...(options.headers || {}),
      },
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      // JWTs expire after 12h; if we were provisioned with a device token,
      // silently get a fresh one instead of surfacing an error (the
      // machine may run unattended for days).
      if (res.status === 401 && this.agentToken && !_isRetry && path !== "/api/auth/device-login") {
        await this.deviceLogin(this.agentToken);
        return this.request(path, options, true);
      }
      const err = new Error(data.error || `Request failed (${res.status})`);
      err.status = res.status;
      throw err;
    }
    return data;
  }

  async login(email, password) {
    const data = await this.request("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    });
    this.setToken(data.token, data.user);
    return data;
  }

  async deviceLogin(agentToken) {
    const data = await this.request("/api/auth/device-login", {
      method: "POST",
      body: JSON.stringify({ agentToken }),
    });
    this.setToken(data.token, data.user);
    this.agentToken = agentToken;
    return data;
  }

  async me() {
    return this.request("/api/auth/me");
  }

  async uploadScreenshot(imageBase64, capturedAt) {
    return this.request("/api/agent/screenshot", {
      method: "POST",
      body: JSON.stringify({ imageBase64, capturedAt }),
    });
  }

  async uploadActivity(events) {
    if (!events.length) return { count: 0 };
    return this.request("/api/agent/activity", {
      method: "POST",
      body: JSON.stringify({ events }),
    });
  }

  async uploadBrowsing(events) {
    if (!events.length) return { count: 0 };
    return this.request("/api/agent/browsing", {
      method: "POST",
      body: JSON.stringify({ events }),
    });
  }

  async checkIn() {
    return this.request("/api/attendance/check-in", { method: "POST", body: JSON.stringify({}) });
  }

  async checkOut() {
    return this.request("/api/attendance/check-out", { method: "POST", body: JSON.stringify({}) });
  }

  async attendanceStatus() {
    return this.request("/api/attendance/status");
  }
}

module.exports = ApiClient;
