// Tracks which application/window is in the foreground, and idle time.
// Polls at a short interval and coalesces consecutive polls of the same
// app into a single "session" (start/end), which keeps upload volume low.
//
// Requires OS-level permissions to read window titles:
//   - macOS: System Settings > Privacy & Security > Accessibility (and
//     Screen Recording on newer macOS versions, for window titles)
//   - Windows: no special permission needed
//   - Linux: works on X11; limited/no support on pure Wayland sessions

const { powerMonitor } = require("electron");

const IDLE_THRESHOLD_SECONDS = 120; // treat as idle after 2 min of no input

class ActivityTracker {
  constructor({ pollIntervalMs = 5000, onFlush, flushIntervalMs = 5 * 60 * 1000 } = {}) {
    this.pollIntervalMs = pollIntervalMs;
    this.flushIntervalMs = flushIntervalMs;
    this.onFlush = onFlush; // callback(events[]) - called periodically with completed sessions
    this.pendingEvents = [];
    this.currentSession = null; // { appName, windowTitle, start, isIdle }
    this.pollTimer = null;
    this.flushTimer = null;
  }

  async pollOnce() {
    let appName = "Unknown";
    let windowTitle = "";

    try {
      const activeWin = require("active-win");
      const result = await activeWin();
      if (result) {
        appName = (result.owner && result.owner.name) || "Unknown";
        windowTitle = result.title || "";
      }
    } catch (err) {
      appName = "Unknown";
    }

    const idleSeconds = powerMonitor.getSystemIdleTime();
    const isIdle = idleSeconds >= IDLE_THRESHOLD_SECONDS;

    const now = new Date().toISOString();
    const effectiveAppName = isIdle ? "Idle" : appName;

    if (
      !this.currentSession ||
      this.currentSession.appName !== effectiveAppName ||
      this.currentSession.isIdle !== isIdle
    ) {
      if (this.currentSession) {
        this.currentSession.end = now;
        this.pendingEvents.push(this.currentSession);
      }
      this.currentSession = {
        appName: effectiveAppName,
        windowTitle: isIdle ? "" : windowTitle,
        start: now,
        isIdle,
      };
    }
  }

  flush() {
    const eventsToSend = [...this.pendingEvents];
    this.pendingEvents = [];

    if (this.currentSession) {
      const now = new Date().toISOString();
      eventsToSend.push({ ...this.currentSession, end: now });
      this.currentSession.start = now;
    }

    if (eventsToSend.length && this.onFlush) {
      return Promise.resolve(this.onFlush(eventsToSend));
    }
    return Promise.resolve();
  }

  start() {
    this.pollTimer = setInterval(() => this.pollOnce(), this.pollIntervalMs);
    this.flushTimer = setInterval(() => this.flush(), this.flushIntervalMs);
    this.pollOnce();
  }

  stop() {
    if (this.pollTimer) clearInterval(this.pollTimer);
    if (this.flushTimer) clearInterval(this.flushTimer);
    this.flush();
  }
}

module.exports = ActivityTracker;
