// Captures the primary screen periodically using Electron's desktopCapturer.
// No renderer window is needed - this runs entirely in the main process.

const { desktopCapturer, screen } = require("electron");

async function captureScreenshot({ maxWidth = 1600, maxHeight = 900 } = {}) {
  const primaryDisplay = screen.getPrimaryDisplay();
  const scaleFactor = primaryDisplay.scaleFactor || 1;

  const sources = await desktopCapturer.getSources({
    types: ["screen"],
    thumbnailSize: {
      width: Math.round(maxWidth * scaleFactor),
      height: Math.round(maxHeight * scaleFactor),
    },
  });

  if (!sources.length) {
    throw new Error("No screen sources available (check screen recording permission on macOS)");
  }

  const source = sources.find((s) => s.display_id === String(primaryDisplay.id)) || sources[0];
  const dataUrl = source.thumbnail.toDataURL(); // "data:image/png;base64,..."
  return dataUrl;
}

module.exports = { captureScreenshot };
