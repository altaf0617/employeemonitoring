; Custom NSIS install/uninstall steps for Office Monitor.
;
; What this does: registers a Scheduled Task that periodically checks
; whether the agent is running and relaunches it if not (see
; installer/watchdog.ps1 for exactly what runs - nothing hidden or
; obfuscated). Removes the task cleanly on uninstall.
;
; IMPORTANT - read before deploying broadly:
; The task below is created for the account running the installer
; (via schtasks with no /RU, which defaults to the invoking user). That's
; correct for a normal interactive install where you're logged in as the
; employee (or install once per employee login). It is NOT correct if you
; deploy via an RMM/GPO tool that installs under a SYSTEM account across a
; fleet - in that case the task would run in Session 0 with no access to
; the interactive desktop, and screenshot/active-window capture would
; silently fail for the relaunched process.
;
; If you're deploying via RMM/GPO, either:
;   (a) adjust the schtasks command below to target the correct interactive
;       user explicitly (/RU "DOMAIN\username"), or
;   (b) skip this automatic registration and instead configure the
;       scheduled task via Task Scheduler's GUI/Group Policy with trigger
;       "At log on" and "Run only when user is logged on" checked, which
;       Windows will correctly bind to whichever user is interactively
;       logged in - this is the simplest reliable option for shared or
;       centrally-managed machines.
;
; Test on one real machine before wide rollout either way.

!macro customInstall
  DetailPrint "Registering Office Monitor watchdog task..."
  nsExec::Exec 'schtasks /create /tn "OfficeMonitorWatchdog" /tr "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File \"$INSTDIR\installer\watchdog.ps1\"" /sc minute /mo 5 /rl limited /f'
!macroend

!macro customUnInstall
  DetailPrint "Removing Office Monitor watchdog task..."
  nsExec::Exec 'schtasks /delete /tn "OfficeMonitorWatchdog" /f'
!macroend
