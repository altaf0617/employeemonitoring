# Office Monitor watchdog.
# Runs on a schedule (installed as a Scheduled Task at install time - see
# installer/custom.nsh). If the agent isn't running, relaunches it.
#
# This is intentionally simple and inspectable - no obfuscation, nothing
# hidden. Any admin can read exactly what it does. Its job is resilience
# against accidental or casual termination (e.g. an employee ending the
# task via Task Manager out of curiosity), not defeating a determined,
# technically capable user who has found their way into PowerShell and
# Task Scheduler - that level of "unstoppable" isn't a real thing for a
# process running under a standard Windows account, and isn't what this
# is trying to be.

$processName = "Office Monitor"
$installRoot = Split-Path $PSScriptRoot -Parent
$exePath = Join-Path $installRoot "Office Monitor.exe"

$running = Get-Process -Name $processName -ErrorAction SilentlyContinue

if (-not $running) {
    if (Test-Path $exePath) {
        Start-Process -FilePath $exePath
    }
}
