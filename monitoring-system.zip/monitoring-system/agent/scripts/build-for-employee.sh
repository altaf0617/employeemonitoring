#!/bin/bash
# Builds a Windows installer for ONE specific employee, with their
# serverUrl/employeeId/agentToken already baked in at
# C:\Program Files\Office Monitor\config.json - nothing to manually copy
# after install. Just run the resulting .exe as admin on their machine.
#
# Usage:
#   ./scripts/build-for-employee.sh "Employee Name" "https://monitor.yourcompany.com" "employee-id" "agent-token"
#
# Get employee-id and agent-token from the admin dashboard: go to
# "Employees & agent setup", click "Generate & download" for the employee.
# The downloaded config.json contains exactly the serverUrl/employeeId/
# agentToken values you need - open it and copy them into this command
# instead of installing that file separately.
#
# Run this on a machine with normal internet access (needed the first time
# to download Electron/electron-builder's dependencies; subsequent builds
# are fast and don't need internet unless a dependency version changes).

set -euo pipefail

if [ "$#" -ne 4 ]; then
  echo "Usage: $0 \"Employee Name\" \"https://server-url\" \"employee-id\" \"agent-token\"" >&2
  exit 1
fi

EMP_NAME="$1"
SERVER_URL="$2"
EMPLOYEE_ID="$3"
AGENT_TOKEN="$4"

cd "$(dirname "$0")/.."   # move to agent/ regardless of where this is called from

echo "Building installer for: $EMP_NAME"
echo "Server: $SERVER_URL"

# Write the credentials this specific build will embed
cat > config.build.json <<EOF
{
  "serverUrl": "$SERVER_URL",
  "employeeId": "$EMPLOYEE_ID",
  "agentToken": "$AGENT_TOKEN"
}
EOF

echo "Running electron-builder..."
npm run build:win

# Sanitize the employee name for use in a filename
SAFE_NAME=$(echo "$EMP_NAME" | tr ' ' '-' | tr -cd 'A-Za-z0-9-')
mkdir -p dist-per-employee
OUTPUT_FILE="dist-per-employee/Office-Monitor-${SAFE_NAME}-Setup.exe"
cp "dist/Office Monitor Setup 1.0.0.exe" "$OUTPUT_FILE"

echo ""
echo "Done: $OUTPUT_FILE"
echo ""
echo "IMPORTANT: this installer has $EMP_NAME's credentials baked into it."
echo "Only send it to $EMP_NAME's machine. If it's copied to someone else's"
echo "machine or leaked, that person's monitoring would report as $EMP_NAME."
echo "If that ever happens, revoke and regenerate their agent token from the"
echo "admin dashboard, then rebuild."

# Reset config.build.json back to the safe placeholder so a plain
# `npm run build:win` (with no employee args) doesn't accidentally ship
# this employee's credentials in a generic build afterward.
cat > config.build.json <<'EOF'
{
  "serverUrl": "https://your-monitoring-server.example.com",
  "employeeId": null,
  "agentToken": null
}
EOF
