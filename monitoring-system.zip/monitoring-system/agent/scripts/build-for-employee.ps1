# Builds a Windows installer for ONE specific employee, with their
# serverUrl/employeeId/agentToken already baked in at
# C:\Program Files\Office Monitor\config.json - nothing to manually copy
# after install. Just run the resulting .exe as admin on their machine.
#
# Usage (from inside the agent folder):
#   .\scripts\build-for-employee.ps1 -EmployeeName "Ali Raza" -ServerUrl "https://monitor.yourcompany.com" -EmployeeId "employee-id" -AgentToken "agent-token"
#
# Get EmployeeId and AgentToken from the admin dashboard: go to
# "Employees & agent setup", click "Get .exe build command" for the
# employee - it gives you a ready-to-paste command. If you're on the
# bash version instead (Git Bash/WSL), use build-for-employee.sh with
# the same values.
#
# Run this on a machine with normal internet access (needed the first
# time to download Electron/electron-builder's dependencies; subsequent
# builds are fast and don't need internet unless a dependency version
# changes).
#
# NOTE: if running scripts is blocked on this machine, you may need:
#   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

param(
    [string]$EmployeeName,
    [string]$ServerUrl,
    [string]$EmployeeId,
    [string]$AgentToken
)

if (-not $EmployeeName -or -not $ServerUrl -or -not $EmployeeId -or -not $AgentToken) {
    Write-Host 'Usage: .\scripts\build-for-employee.ps1 -EmployeeName "Employee Name" -ServerUrl "https://server-url" -EmployeeId "employee-id" -AgentToken "agent-token"'
    exit 1
}

$ErrorActionPreference = "Stop"

# Move to the agent/ folder regardless of where this script is called from
# ($PSScriptRoot is scripts/, so go up one level)
Set-Location (Join-Path $PSScriptRoot "..")

Write-Host "Building installer for: $EmployeeName"
Write-Host "Server: $ServerUrl"

# Write the credentials this specific build will embed
$configContent = @"
{
  "serverUrl": "$ServerUrl",
  "employeeId": "$EmployeeId",
  "agentToken": "$AgentToken"
}
"@
Set-Content -Path "config.build.json" -Value $configContent -Encoding utf8

Write-Host "Running electron-builder..."
npm run build:win
if ($LASTEXITCODE -ne 0) {
    Write-Error "Build failed (npm exited with code $LASTEXITCODE). config.build.json was NOT reset - check it before retrying."
    exit 1
}

# Sanitize the employee name for use in a filename (letters, numbers, hyphens only)
$SafeName = ($EmployeeName -replace ' ', '-') -replace '[^A-Za-z0-9\-]', ''

New-Item -ItemType Directory -Force -Path "dist-per-employee" | Out-Null
$OutputFile = "dist-per-employee\Office-Monitor-$SafeName-Setup.exe"
Copy-Item -Path "dist\Office Monitor Setup 1.0.0.exe" -Destination $OutputFile -Force

Write-Host ""
Write-Host "Done: $OutputFile"
Write-Host ""
Write-Host "IMPORTANT: this installer has $EmployeeName's credentials baked into it." -ForegroundColor Yellow
Write-Host "Only send it to $EmployeeName's machine. If it's copied to someone else's" -ForegroundColor Yellow
Write-Host "machine or leaked, that person's monitoring would report as $EmployeeName." -ForegroundColor Yellow
Write-Host "If that ever happens, revoke and regenerate their agent token from the" -ForegroundColor Yellow
Write-Host "admin dashboard, then rebuild." -ForegroundColor Yellow

# Reset config.build.json back to the safe placeholder so a plain
# `npm run build:win` (with no employee args) doesn't accidentally ship
# this employee's credentials in a generic build afterward.
$placeholderContent = @"
{
  "serverUrl": "https://your-monitoring-server.example.com",
  "employeeId": null,
  "agentToken": null
}
"@
Set-Content -Path "config.build.json" -Value $placeholderContent -Encoding utf8
